package com.example.cnExpense.service;

import com.example.cnExpense.DAL.IncomeDAL;
import com.example.cnExpense.entities.Income;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class IncomeService {

    @Autowired
    IncomeDAL incomeDAL;

    public Income getIncome(Integer id){
        return incomeDAL.getById(id);
    }

    public Income saveIncome(Income income,Integer userId){
        return incomeDAL.saveIncome(income,userId);
    }
}
