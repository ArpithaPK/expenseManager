package com.example.cnExpense.DAL;

import com.example.cnExpense.entities.Expense;
import com.example.cnExpense.entities.Income;
import org.springframework.stereotype.Repository;

@Repository
public interface ExpenseDAL {

    Income saveExpense(Integer incomeId, Expense expense);
}

