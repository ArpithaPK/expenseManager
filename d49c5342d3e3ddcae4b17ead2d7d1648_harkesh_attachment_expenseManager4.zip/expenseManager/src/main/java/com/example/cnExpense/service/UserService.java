package com.example.cnExpense.service;

import com.example.cnExpense.DAL.UserDAL;
import com.example.cnExpense.entities.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.time.LocalDate;
import java.util.List;

@Service
public class UserService {

    @Autowired
    UserDAL userDAL;

    @Transactional
    public User getById(int id){
        return userDAL.getById(id);
    }

    @Transactional
    public List<User> getAllUsers() {
        return userDAL.getAllUsers();
    }

    @Transactional
    public User saveUser(User user) {
        return userDAL.saveUser(user);
    }

    @Transactional
    public boolean checkUserExists(User user) {
        if(userDAL.getById(user.getId())!=null)
            return true;
        else
            return false;
    }

    @Transactional
    public User findUser(User user) {
//        if(userDAL.getById(user.getId())!=null)
//            return user;
//        else
//            return null;

        return userDAL.findUser(user);
    }

    @Transactional
    public List<User> getUsersByDate(LocalDate date) {
        return userDAL.getUsersByDate(date);
    }

    @Transactional
    public List<User> getUsersByType(String incomeType,String expenseType) {
        return userDAL.getUsersByType(incomeType,expenseType);
    }


    public List<User> getUserByCalendar(String day, String month, String year) {
        return userDAL.getUserByCalendar(day,month,year);
    }
}
