package com.example.cnExpense.DAL;

import com.example.cnExpense.entities.User;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface UserDAL {

        User getById(int id);

        List<User> getAllUsers();

        User saveUser(User user);

        List<User> getUsersByDate(LocalDate date);

        List<User> getUsersByType(String incomeType,String expenseType);


        User findUser(User user);

        List<User> getUserByCalendar(String day, String month, String year);
}
