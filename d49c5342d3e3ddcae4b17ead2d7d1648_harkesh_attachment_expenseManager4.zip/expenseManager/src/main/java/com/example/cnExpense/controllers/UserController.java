package com.example.cnExpense.controllers;

import com.example.cnExpense.entities.User;
import com.example.cnExpense.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users/")
public class UserController {

    @Autowired
    UserService userService;

    @GetMapping("/allUsers")
    public List<User> getAllUSers(){
        return userService.getAllUsers();
    }

    @GetMapping("/{id}")
    public User getUserById(@PathVariable Integer id){
        return userService.getById(id);
    }

    @PostMapping("/save")
    public User saveUser(@RequestBody User user){
        return userService.saveUser(user);
    }

    @PostMapping("/checkUserExist")
    public boolean checkUserExist(@RequestBody User user){
        return userService.checkUserExists(user);
    }


    @PostMapping("/find")
    public User findUSer(@RequestBody User user){
        return userService.findUser(user);
    }

    @GetMapping("/filteredUserListByCalendar")
    public List<User> filterByCalendar(@RequestParam(value = "day", required = false) String day,@RequestParam(value = "month", required = false) String month,@RequestParam(value = "year", required = false) String year){
//        LocalDate date = LocalDate.of(Integer.parseInt(year),
//                Integer.parseInt(month),
//                Integer.parseInt(day));

//        return userService.getUsersByDate(date);
        return userService.getUserByCalendar(day, month, year);
    }

    @GetMapping("/filteredUserListByType")
    public List<User> filterByType(@RequestParam(value = "incomeType", required = false) String incomeType,@RequestParam(value = "expenseType", required = false) String expenseType){
        return userService.getUsersByType(incomeType,expenseType);
    }

}
