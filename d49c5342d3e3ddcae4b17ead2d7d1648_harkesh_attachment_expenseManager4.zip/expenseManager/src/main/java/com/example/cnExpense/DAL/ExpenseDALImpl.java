package com.example.cnExpense.DAL;

import com.example.cnExpense.entities.Expense;
import com.example.cnExpense.entities.Income;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;

@Repository
public class ExpenseDALImpl implements ExpenseDAL{

    @Autowired
    EntityManager entityManager;


    @Override
    public Income saveExpense(Integer incomeId, Expense expense) {
        Session session = entityManager.unwrap(Session.class);
        Integer expenseId = (Integer) session.save(expense);

        Expense savedExpense = session.get(Expense.class, expenseId);
        Income savedIncome = session.get(Income.class, incomeId);

        savedIncome.setExpense(savedExpense);
        session.update(savedIncome);

//        expense.setIncome(incomeDAL.getById(incomeId));
        return savedIncome;
    }
}
