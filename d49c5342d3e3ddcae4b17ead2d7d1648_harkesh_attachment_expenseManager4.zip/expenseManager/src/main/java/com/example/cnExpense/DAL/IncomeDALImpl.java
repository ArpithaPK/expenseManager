package com.example.cnExpense.DAL;

import com.example.cnExpense.entities.Income;
import com.example.cnExpense.entities.User;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;

@Repository
public class IncomeDALImpl implements IncomeDAL{

    @Autowired
    EntityManager entityManager;


    @Override
    public Income getById(int id) {
        Session session = entityManager.unwrap(Session.class);
        return session.get(Income.class,id);
    }

    @Override
    public Income saveIncome(Income income, Integer id) {
        Session session = entityManager.unwrap(Session.class);
        Integer incomeId = (Integer) session.save(income);
        Income savedIncome = session.get(Income.class, incomeId);
//        income.setId(id);
        User user = session.get(User.class, id);
        user.getIncomes().add(savedIncome);
        savedIncome.getUsers().add(user);
        session.save(income);
        session.save(user);


        return savedIncome;
    }
}
