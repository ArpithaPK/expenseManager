package com.example.cnExpense.DAL;

import com.example.cnExpense.entities.Income;
import org.springframework.stereotype.Repository;

@Repository
public interface IncomeDAL {

    Income getById(int id);

    Income saveIncome(Income income,Integer id);



}
