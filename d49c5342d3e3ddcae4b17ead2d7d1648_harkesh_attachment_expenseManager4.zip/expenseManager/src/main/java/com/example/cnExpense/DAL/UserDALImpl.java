package com.example.cnExpense.DAL;

import com.example.cnExpense.entities.Income;
import com.example.cnExpense.entities.User;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Repository
public  class UserDALImpl implements UserDAL {

    @Autowired
    private EntityManager entityManager;

    @Autowired
    IncomeDAL incomeDAL;


    @Override
    public User getById(int id) {
        Session session = entityManager.unwrap(Session.class);
        return session.get(User.class,id);

    }

    @Override
    public List<User> getAllUsers() {
        Session session = entityManager.unwrap(Session.class);
        List<User> userList = session.createQuery(
                "Select u from User u", User.class).getResultList();

        return userList;
    }

    @Override
    public User saveUser(User user) {
        Session session = entityManager.unwrap(Session.class);
        Integer userId = (Integer) session.save(user);
        return session.get(User.class, userId);
    }

    // this is not correct
    @Override
    public List<User> getUsersByDate(LocalDate date) {
        List<User> output = new ArrayList<>();
        List<User> userList = getAllUsers();
        for(User user : userList){
            if(incomeDAL.getById(user.getId()).getDate().equals(date)){
                output.add(user);
        }
        }
        return output;



    }

    @Override
        public List<User> getUsersByType(String incomeType,String expenseType){
        List<User> userList =getAllUsers();
        List<User> output = new ArrayList<>();
        Session session = entityManager.unwrap(Session.class);
        for(User user:userList) {
            for (Income income : user.getIncomes()) {
                if (income.getDescription().equalsIgnoreCase(incomeType)
                        && income.getExpense().getDescription().equalsIgnoreCase(expenseType)) {
                    output.add(user);
                }
            }
            }
            return output;
        }

    @Override
    public User findUser(User user) {
//        Session session = entityManager.unwrap(Session.class);
        for(User existingUser :getAllUsers())
        {
            if(existingUser.getUsername()!=null && existingUser.getUsername().equalsIgnoreCase(user.getUsername()))
            {
                return existingUser;
            }
        }
        return null;
    }

    @Override
    public List<User> getUserByCalendar(String day, String month, String year) {
        List<User> filteredList = new ArrayList<>();
        List<User> userList= getAllUsers();

        for (User user : userList) {
            for (Income income : user.getIncomes()) {
                // checking day
                if (((income.getDate()!=null) && (day != null && !day.isEmpty() && !(Integer.parseInt(day)==income.getDate().getDayOfMonth())))
                    // checking month
                    && ((month != null && !month.isEmpty() && !(Integer.parseInt(month)==income.getDate().getMonthValue())))
                    // checking year
                    &&  ((year != null && !year.isEmpty() && !(Integer.parseInt(year)==income.getDate().getYear())))) {

                    filteredList.add(user);
                    break;
                }
            }

        }
        return filteredList;
    }

}


